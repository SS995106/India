Executable JAR
--------------

This is an executable JAR package. To run it, use the following command:

java -jar states.jar